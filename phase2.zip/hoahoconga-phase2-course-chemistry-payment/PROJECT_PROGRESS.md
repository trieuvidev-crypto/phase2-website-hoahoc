# PROJECT_PROGRESS.md — HoaHocCoNga.Com

Cập nhật lần cuối: sau khi hoàn thành Phase 2 (RBAC runtime) + Phase 3 (Core System Services).

## Trạng thái tổng quan

Đang triển khai theo `02_DEVELOPMENT_ROADMAP.md`. Không lệch thứ tự phụ thuộc.
Toàn bộ code trong danh sách "ĐÃ XONG" bên dưới là code thật, không có
placeholder, không có TODO, đã qua kiểm tra brace-balance và review thủ công
(không có môi trường PHP CLI trong sandbox nên không chạy được `php -l`
hay test thật — cần chạy `php app/Console/migrate.php` + `php -l` trên máy
có PHP trước khi deploy production).

## ĐÃ XONG

### Phase 1 — Foundation
- [x] M1.1 Bootstrap (`bootstrap/app.php`, `bootstrap/helpers.php`, autoload, config loader)
- [x] M1.2 Router + middleware pipeline (`app/Core/Router.php`)
- [x] M1.3 Schema nền tảng (7 migration: Auth, RBAC, System Reference, Media, Course/Chapter/Lesson, Chemistry, Payment)
- [x] M1.4 Seeder thật (roles/permissions, grades/subjects/provinces, chemistry — 20 elements/20 compounds/6 reactions)

### Phase 2 — Auth, Authorization, Security Core
- [x] M2.1 Authentication đầy đủ (register/login/refresh/logout/forgot/reset — `AuthService`, `AuthController`, `UserRepository`, `TokenService`)
- [x] M2.2 RBAC runtime enforcement (`PermissionService` có cache + role_hierarchy, `PermissionMiddleware`, `Policy` base + `CoursePolicy`)
- [x] M2.3 Session/Token security — JWT + CSRF + Rate Limit + **session-based login cho web đã xong** (`AuthService::login($useSession)`, session_regenerate_id chống fixation, logout xóa cả session lẫn refresh token)

### Phase 3 — Core System Services
- [x] M3.1 Cache (`App\Core\Cache`, file-based, TTL, remember())
- [x] M3.2 Event/Hook system (`App\Core\Events\*`, dispatcher + đăng ký tại `bootstrap/events.php`, đã nối vào AuthService)
- [x] M3.3 Notification core — `NotificationService` (in-app + email theo preference), `MailerService` (SMTP tự viết có STARTTLS/AUTH LOGIN, fallback `mail()` PHP built-in cho cPanel), `NotificationRepository`, migration 0008. `AuthService::requestPasswordReset` giờ gửi email thật.
- [x] M3.4 Media/Upload service (`MediaUploadService`, `MediaRepository`, validate MIME thật + chống trùng lặp SHA-256)
- [x] M3.5 Logging (`App\Core\Logger`, JSON theo category, tự redact dữ liệu nhạy cảm)

### Phase 8 (một phần, làm sớm để giải quyết nợ kỹ thuật)
- [x] `BankQrDriver` + `VietQrPayloadBuilder` — sinh mã QR chuyển khoản chuẩn VietQR/EMVCo thật (TLV + CRC16-CCITT đúng thuật toán), driver duy nhất hoạt động thật trong `config/payment.php`. **Chưa có** `PaymentService`/`OrderController` gọi tới driver này — đó vẫn là việc của Phase 8 đầy đủ.

### Phase 5 — Course/Chapter/Lesson (Teacher + Admin)
- [x] `CourseRepository`, `ChapterRepository`, `LessonRepository` — data access thuần, không business logic.
- [x] `CourseService` (create/update/publish/archive/duplicate/delete) — dùng `CoursePolicy` chặn quyền sở hữu, dùng `SlugGenerator` (mới, tự viết, xử lý dấu tiếng Việt) sinh slug duy nhất, invalidate cache listing qua `Cache::forgetPrefix()`.
- [x] `ChapterService`, `LessonService` — đầy đủ CRUD + reorder, kiểm tra chapter/lesson thuộc đúng course trước khi thao tác.
- [x] `CourseController`, `ChapterController`, `LessonController` — mỏng, map RuntimeException message sang HTTP status (404/403/422) theo tiền tố tiếng Việt.
- [x] Route thật đã đăng ký trong `routes/api.php` (trước đây chỉ là comment mẫu) — `PermissionMiddleware` áp cho từng action theo đúng permission slug đã seed ở Phase 1 (`courses.create`, `courses.edit`, `courses.publish`, `courses.delete`, `lessons.create`, `lessons.edit`).
- [x] `LessonCreatedEvent` + `NotifyEnrolledStudentsListener` — khi giáo viên thêm bài học mới vào khóa học **đã xuất bản**, mọi học viên đang ghi danh nhận thông báo qua `NotificationService` đã có sẵn từ Phase 3. Đăng ký tại `bootstrap/events.php`.
- [x] `CourseCreatedEvent`, `CoursePublishedEvent` — đã dispatch, chưa có listener riêng (không cần thiết ngay, không tạo "chay" khi đã có ít nhất một use case rõ ràng — xem comment trong `bootstrap/events.php`).

## LỖI ĐÃ PHÁT HIỆN VÀ SỬA TRONG QUÁ TRÌNH REVIEW

- **`Cache::forgetPrefix()`** đọc `$meta['key']` để so khớp tiền tố, nhưng `Cache::put()` (viết ở lượt trước) không hề lưu `key` vào envelope — nghĩa là invalidate theo prefix sẽ luôn no-op một cách âm thầm. Đã sửa `put()` để lưu `key` vào envelope. Đây là kiểu lỗi khó phát hiện nếu không chủ động review lại code cũ khi module mới bắt đầu dùng đến nó — bài học: mỗi khi một service mới gọi vào một hàm Core đã viết từ trước, phải đọc lại toàn bộ implementation của hàm đó, không giả định nó đúng.
- **Trùng lặp bảng ánh xạ bỏ dấu tiếng Việt** ở 3 nơi (`SlugGenerator`, `ChemistryCompoundService`, seeder 0003) — vi phạm trực tiếp "never duplicate code". Đã trích xuất thành `App\Core\VietnameseTextNormalizer` dùng chung; cả 3 nơi và seeder giờ gọi cùng một hàm, đảm bảo kết quả chuẩn hóa luôn khớp nhau giữa lúc seed và lúc tra cứu.
- **`EquationBalancerService::rowEchelonForm()`** có một dòng return tự tham chiếu vô nghĩa (`[$matrix, ..., $pivotColumns][0] === $matrix ? ... : ...` — luôn đúng, hai nhánh giống hệt nhau) sót lại từ lúc viết nháp thuật toán. Đã dọn thành return đơn giản. Đã trace tay thuật toán trên ví dụ H₂ + O₂ → H₂O để xác nhận kết quả đúng (2H₂ + O₂ → 2H₂O) trước khi coi module hoàn thành.
- **`OrderService::applyCoupon()`** ban đầu tính discount nhưng quên ghi `coupon_usage` + tăng `used_count` — nghĩa là giới hạn lượt dùng mã giảm giá sẽ không bao giờ được thực thi. Đã sửa, đồng thời bọc toàn bộ `createFromCourse()` trong transaction để đơn hàng + order_item + coupon_usage luôn nhất quán.

### Phase 8 — Order/Payment (Bank QR end-to-end)
- [x] `OrderRepository`, `PaymentRepository` — data access thuần.
- [x] `OrderService::createFromCourse()` — kiểm tra course đã publish, chưa enroll trùng, áp dụng coupon có validate đầy đủ (thời hạn, giá trị tối thiểu, giới hạn lượt dùng tổng + theo user), tự động set order status='paid' nếu tổng tiền = 0 (khóa học miễn phí/giảm 100%).
- [x] `PaymentService::initiate()` — gọi `BankQrDriver` đã có sẵn, tái sử dụng payment pending còn hạn thay vì sinh QR mới liên tục.
- [x] `PaymentService::confirmManually()` — luồng xác nhận thủ công duy nhất cho Bank QR (không có callback tự động), transaction-safe, dispatch `PaymentCompletedEvent`.
- [x] `GrantCourseAccessListener` — lắng nghe `PaymentCompletedEvent`, tự tạo `course_enrollments`, tăng `enrollment_count`, gửi thông báo qua `NotificationService` đã có — **không** có logic cấp quyền nào nằm trong PaymentService, đúng nguyên tắc tách module qua event.
- [x] `OrderController` (checkout, học sinh), `Admin\PaymentController` (danh sách chờ xác nhận + confirm/reject) — route thật trong `routes/api.php` + `routes/admin.php`.
- [x] Seeder `payment_bank_accounts` (1 tài khoản DEMO — **bắt buộc đổi trước khi vận hành thật**, đã ghi rõ cảnh báo trong seeder).

### Phase 6 — Chemistry Engine logic
- [x] `ChemicalFormulaParser` — parser đệ quy xử lý ngoặc lồng nhau (Ca(OH)₂, Al₂(SO₄)₃), không phải regex đơn giản.
- [x] `Fraction` — số hữu tỉ chính xác (tử số/mẫu số nguyên, tự động rút gọn) để tránh sai số dấu phẩy động khi cân bằng phương trình.
- [x] `EquationBalancerService` — cân bằng phương trình bằng khử Gauss thật trên ma trận hệ số nguyên tố, phát hiện đúng trường hợp vô nghiệm/nhiều nghiệm độc lập thay vì trả kết quả sai. Đã kiểm chứng bằng tay.
- [x] `ChemistryCalculatorService` — molar mass (tính từ dữ liệu nguyên tố đã seed, không hardcode), pH, pha loãng (C₁V₁=C₂V₂, giải cho ẩn bất kỳ trong 4 biến), stoichiometry cơ bản. Mỗi kết quả đều kèm formula + steps + explanation theo đúng yêu cầu `CHEMISTRY_DOMAIN.md`.
- [x] `ChemistryCompoundService` — tra cứu theo formula/UUID, tìm kiếm alias chịu lỗi chính tả (khớp chính xác trước, LIKE fallback sau).
- [x] `ChemistryRepository` — data access cho elements/compounds/aliases/reactions/participants.
- [x] `ChemistryController` + route công khai `/api/v1/chemistry/*` (không cần đăng nhập — công cụ Hóa học là nội dung SEO/marketing công khai theo `HOME_PAGE_SPEC.md`).

## CHƯA LÀM (theo đúng thứ tự roadmap)

- Phase 4: Portal shells (Admin/Teacher/Student layout — chưa có UI nào, mới chỉ có backend)
- Phase 6 (phần còn lại): Question Bank, Quiz Engine, Flashcards, AI Tutor
- Phase 7: Node.js/Socket.IO server (chưa có bất kỳ file nào trong `nodeapp/`)
- Phase 8 (phần còn lại): Invoice PDF generation, Refund workflow admin UI, revenue analytics
- Phase 9-12: SEO, Search, UI polish, Optimization, Production

## RỦI RO / NỢ KỸ THUẬT ĐANG BIẾT

1. ~~`BankQrDriver` chưa tồn tại~~ — **ĐÃ SỬA**: `BankQrDriver` + `VietQrPayloadBuilder` đã hoạt động thật (chuẩn VietQR/EMVCo, CRC16-CCITT đúng thuật toán). Còn thiếu `PaymentService`/`OrderController` gọi tới nó — thuộc Phase 8.
2. ~~Session-based login chưa có~~ — **ĐÃ SỬA**: `AuthService::login($identifier, $password, $ip, $useSession)` hỗ trợ cả hai; `AuthController` nhận field `via=session` từ form web.
3. Chưa test được bằng PHP CLI thật (sandbox không có PHP) — chỉ kiểm tra cú pháp bằng brace-balance thủ công. **Bắt buộc chạy `php -l` trên toàn bộ file trước khi deploy.**
4. `payment_bank_accounts` table đã có trong migration 0007 nhưng chưa có seeder điền dữ liệu mẫu — `BankQrDriver::initiate()` sẽ ném lỗi "chưa cấu hình tài khoản ngân hàng" cho tới khi admin (hoặc seeder) thêm ít nhất một dòng `is_active = 1`.

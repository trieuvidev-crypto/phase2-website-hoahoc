# NEXT_TASK.md

## Vừa hoàn thành

Phase 8 core: OrderService (checkout + coupon validation đầy đủ, transaction-safe),
PaymentService (initiate qua BankQrDriver + confirmManually), GrantCourseAccessListener
(cấp quyền khóa học qua event, không hardcode trong PaymentService), Controllers +
routes cho học sinh và admin, seeder payment_bank_accounts. Đã sửa 1 bug (coupon_usage
không được ghi nhận).

## Đang làm ngay bây giờ: Phase 7 — Node.js/Socket.IO server

Lý do ưu tiên: đây là hạng mục lớn duy nhất trong roadmap gốc chưa có bất kỳ
dòng code nào (`nodeapp/` rỗng), và giờ đã có đủ dữ liệu thật (Course, Payment,
Notification) để Realtime module có ý nghĩa kết nối tới — không còn lý do
để trì hoãn thêm.

Phạm vi cụ thể (theo đúng REALTIME ARCHITECTURE trong PROJECT.md):
- `nodeapp/server.js` + `nodeapp/socket.js` — khởi tạo Socket.IO server độc lập.
- `nodeapp/authentication/` — xác thực kết nối bằng JWT (dùng chung secret
  với `config/security.php` phía PHP — đọc từ `.env`).
- `nodeapp/rooms/` — room theo user/course/admin per kiến trúc đã định
  trong Architecture Report §6.
- `nodeapp/events/` — xử lý các event cơ bản: `user.connected`,
  `user.disconnected`, `notification.created` (relay từ PHP).
- Cầu nối PHP → Node: một endpoint nội bộ trên Node (localhost-only,
  shared secret từ `.env` `NODE_INTERNAL_SECRET`) để PHP gọi khi cần
  broadcast (ví dụ sau khi `NotificationService::notify()` tạo thông báo).
- **Không** đưa business logic vào Node — Node chỉ relay sự kiện.

## Sau đó: Phase 4 — Portal shells (Admin/Teacher/Student UI)

Bắt đầu UI sau khi Realtime có endpoint để kết nối tới, tránh phải quay lại
sửa UI khi thêm realtime sau.

## Không được làm trước Phase 7 và Phase 4

Quiz Engine/Question Bank (phần còn lại Phase 6), SEO automation (Phase 9).

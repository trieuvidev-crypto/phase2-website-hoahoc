<?php

declare(strict_types=1);

use App\Controllers\HomeController;
use App\Middlewares\CsrfMiddleware;
use App\Middlewares\SecurityHeadersMiddleware;

/** @var \App\Core\Router $router */

$router->group(['middleware' => [SecurityHeadersMiddleware::class, CsrfMiddleware::class]], function ($router) {
    $router->get('/', [HomeController::class, 'index']);
    $router->name('home');

    $router->get('/health', [HomeController::class, 'health']);
    $router->name('health');
});

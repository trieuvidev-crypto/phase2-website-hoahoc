<?php

declare(strict_types=1);

/**
 * Usage: php app/Console/migrate.php
 *
 * Runs every .sql file in database/migrations/ in filename order,
 * tracking applied migrations in `schema_migrations` so re-running is
 * idempotent. This is the only supported way to apply schema changes —
 * never run raw SQL against production by hand.
 */

require_once __DIR__ . '/../../bootstrap/helpers.php';

(function (): void {
    $path = dirname(__DIR__, 2) . '/.env';

    if (!is_file($path)) {
        return;
    }

    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value, " \t\n\r\0\x0B\"'");
        putenv(trim($key) . '=' . $_ENV[trim($key)]);
    }
})();

$config = config('database.connections.' . config('database.default'));

$dsn = sprintf('mysql:host=%s;port=%d;charset=%s', $config['host'], $config['port'], $config['charset']);
$pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);

$dbName = $config['database'];
$pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET {$config['charset']} COLLATE {$config['collation']}");
$pdo->exec("USE `{$dbName}`");

$migrationsTable = config('database.migrations_table', 'schema_migrations');

$pdo->exec("
    CREATE TABLE IF NOT EXISTS `{$migrationsTable}` (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        migration VARCHAR(191) NOT NULL,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_migration (migration)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$applied = $pdo->query("SELECT migration FROM `{$migrationsTable}`")->fetchAll(PDO::FETCH_COLUMN);

$migrationFiles = glob(dirname(__DIR__, 2) . '/database/migrations/*.sql');
sort($migrationFiles);

foreach ($migrationFiles as $file) {
    $name = basename($file);

    if (in_array($name, $applied, true)) {
        echo "SKIP  {$name} (already applied)\n";
        continue;
    }

    echo "APPLY {$name} ... ";

    $sql = file_get_contents($file);

    // Naive statement splitting on ';' — sufficient because these migrations
    // contain no stored procedures/triggers with internal DELIMITER blocks.
    // If a future migration needs those, this runner must be extended first.
    try {
        $pdo->beginTransaction();

        foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
            if ($statement === '') {
                continue;
            }
            $pdo->exec($statement);
        }

        $stmt = $pdo->prepare("INSERT INTO `{$migrationsTable}` (migration) VALUES (:name)");
        $stmt->execute(['name' => $name]);

        $pdo->commit();
        echo "OK\n";
    } catch (Throwable $e) {
        $pdo->rollBack();
        echo "FAILED\n";
        fwrite(STDERR, "Migration {$name} failed: " . $e->getMessage() . "\n");
        exit(1);
    }
}

echo "\nAll migrations applied.\n";

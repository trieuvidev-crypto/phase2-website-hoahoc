# HoaHocCoNga.Com — Nền tảng học Hóa học

Đây là phần khởi tạo (Phase 1) của dự án theo `02_DEVELOPMENT_ROADMAP.md`:
bootstrap ứng dụng, router, tầng bảo mật cốt lõi, module Xác thực (Auth)
đầy đủ, và schema cơ sở dữ liệu cho các nhóm nền tảng (Auth, RBAC, dữ liệu
tham chiếu hệ thống, Khóa học/Chương/Bài học, Chemistry Engine cốt lõi,
Thanh toán Bank QR).

## Yêu cầu hệ thống

- PHP 8.3+ với các extension: pdo_mysql, mbstring, openssl, json
- MySQL 8+
- Composer (chỉ dùng để autoload, không dùng framework nào)

## Cài đặt

```bash
composer install
cp .env.example .env
# Chỉnh sửa .env: thông tin kết nối MySQL, APP_KEY, JWT_SECRET, v.v.

php app/Console/migrate.php        # Tạo toàn bộ schema
php database/seeders/run_all.php   # Seed dữ liệu thật (vai trò, khối lớp, hóa học)
```

Sau đó trỏ document root của Apache/PHP vào thư mục `public/`.

## Kiểm tra hệ thống

```
GET /health
```

Trả về tình trạng kết nối cơ sở dữ liệu và thông tin ứng dụng.

## Đã hoàn thành trong Phase 1

- Bootstrap ứng dụng, DI container tự viết, Router hỗ trợ group/middleware/named route.
- Tầng bảo mật: CSRF, Rate Limiting (không phụ thuộc Redis), JWT (tự viết HS256), Security Headers.
- Module Xác thực đầy đủ: đăng ký, đăng nhập, làm mới token, đăng xuất, quên/đặt lại mật khẩu — toàn bộ thông báo bằng tiếng Việt.
- Schema: `users`, RBAC đầy đủ, dữ liệu tham chiếu (tỉnh/thành, trường, khối lớp, môn học), `courses`/`course_chapters`/`course_lessons`/`course_enrollments`, Chemistry Engine (`chemistry_elements`, `chemistry_compounds`, `chemistry_reactions`), `orders`/`payments` với driver Bank QR.
- Seeder thật: 7 vai trò hệ thống, 48 quyền hạn, 8 khối lớp, 4 môn học, 8 danh mục khóa học, 20 nguyên tố hóa học, 20 hợp chất, 6 phản ứng hóa học có giải thích đầy đủ bằng tiếng Việt.

## Đã hoàn thành trong Phase 2 + Phase 3 (Core System Services)

- **Cache** (`App\Core\Cache`): file-based, TTL, `remember()`, không phụ thuộc Redis.
- **Event/Hook system** (`App\Core\Events\*`): dispatcher đồng bộ, đăng ký tại `bootstrap/events.php`, lỗi ở listener không làm hỏng transaction nghiệp vụ đã commit. Đã nối vào `AuthService::register()` (phát `UserRegisteredEvent`, có `LogUserRegisteredListener` xử lý).
- **Logger** (`App\Core\Logger`): ghi log JSON theo category/level, tự động redact các trường nhạy cảm (password, token, ...), đúng theo `LOGGING_STANDARD.md`.
- **RBAC runtime enforcement**: `PermissionService` (kiểm tra quyền có cache, hỗ trợ role_hierarchy), `PermissionMiddleware` (chặn route theo permission slug), `Policy` base + `CoursePolicy` (kiểm tra quyền sở hữu tài nguyên, không chỉ vai trò).
- **Media Upload Service**: validate đuôi file + MIME thật (không tin client), giới hạn dung lượng, chống trùng lặp qua SHA-256, đổi tên UUID, lưu ngoài webroot — đúng `FILE_STORAGE.md` và `SECURITY_CHECKLIST.md`.
- **Notification core**: `NotificationService` (in-app + email theo preference từng user), `MailerService` với `SmtpClient` tự viết (EHLO/STARTTLS/AUTH LOGIN thật) và fallback `mail()` PHP built-in cho cPanel không cần cấu hình SMTP.
- **Session-based login cho web**: `AuthService::login()` hỗ trợ cả JWT (API) lẫn session (`session_regenerate_id` chống fixation), song song tồn tại đúng theo kiến trúc dual-auth.
- **Bank QR payment driver**: `BankQrDriver` + `VietQrPayloadBuilder` sinh mã QR chuyển khoản chuẩn VietQR/EMVCo thật (cấu trúc TLV + checksum CRC16-CCITT đúng thuật toán, không phải giả lập).

## Đã hoàn thành trong Phase 5 (Course/Chapter/Lesson)

Repository + Service + Controller đầy đủ cho Course/Chapter/Lesson (create/update/publish/archive/duplicate/delete/reorder), `CoursePolicy` kiểm tra quyền sở hữu, route thật trong `routes/api.php`, `LessonCreatedEvent` tự động thông báo học viên đang ghi danh khi có bài học mới trong khóa học đã xuất bản.

## Đã hoàn thành trong Phase 6 (Chemistry Engine logic)

`ChemicalFormulaParser` (parser đệ quy xử lý ngoặc lồng nhau), `Fraction` (số hữu tỉ chính xác), `EquationBalancerService` (cân bằng phương trình bằng khử Gauss thật — đã kiểm chứng bằng tay), `ChemistryCalculatorService` (molar mass/pH/dilution/stoichiometry), `ChemistryCompoundService` (tra cứu alias chịu lỗi chính tả), route công khai `/api/v1/chemistry/*`.

## Đã hoàn thành trong Phase 8 (Order/Payment — Bank QR end-to-end)

`OrderService` (checkout + validate coupon đầy đủ, transaction-safe), `PaymentService` (khởi tạo QR qua `BankQrDriver`, xác nhận thủ công), `GrantCourseAccessListener` (cấp quyền khóa học qua event khi thanh toán thành công), Controller + route cho học sinh (`/api/v1/orders/checkout`) và admin (`/administrator/payments/*`).

## Chưa có (theo đúng lộ trình ở `02_DEVELOPMENT_ROADMAP.md`)

Question Bank, Quiz Engine, Flashcards, AI Tutor (phần còn lại Phase 6), Node.js/Socket.IO server (Phase 7 — hoàn toàn chưa bắt đầu), Forum, Chat, Gamification, Blog, Search, Admin/Teacher/Student UI. Xem `NEXT_TASK.md` để biết module tiếp theo và lý do ưu tiên.

## Quy ước bắt buộc (không được vi phạm)

- Không dùng Laravel/CodeIgniter/Symfony/React/Vue/Angular/Bootstrap/Tailwind.
- Mọi truy vấn SQL đều qua prepared statement (`App\Core\Database`).
- Controller không được chứa business logic — logic thuộc về Service.
- Repository chỉ được chứa truy vấn dữ liệu, không chứa business rule.
- Mọi bảng nghiệp vụ đều có `uuid`, `created_at`, `updated_at`, `deleted_at`.
- Mọi thông báo hướng tới người dùng (validation, lỗi, API message) đều bằng tiếng Việt.
- Mọi domain event mới phải đăng ký listener tại `bootstrap/events.php`.
